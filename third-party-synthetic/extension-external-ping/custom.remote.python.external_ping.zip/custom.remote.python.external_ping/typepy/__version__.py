__author__ = "Tsuyoshi Hombashi"
__copyright__ = "Copyright 2017, {}".format(__author__)
__license__ = "MIT License"
__version__ = "1.1.1"
__maintainer__ = __author__
__email__ = "tsuyoshi.hombashi@gmail.com"
