class METag:
    def __init__(self):
        pass
