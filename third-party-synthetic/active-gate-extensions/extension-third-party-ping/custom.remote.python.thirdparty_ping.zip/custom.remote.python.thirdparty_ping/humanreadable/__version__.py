__author__ = "Tsuyoshi Hombashi"
__copyright__ = "Copyright 2019, {}".format(__author__)
__license__ = "MIT License"
__version__ = "0.1.0"
__maintainer__ = __author__
__email__ = "tsuyoshi.hombashi@gmail.com"
