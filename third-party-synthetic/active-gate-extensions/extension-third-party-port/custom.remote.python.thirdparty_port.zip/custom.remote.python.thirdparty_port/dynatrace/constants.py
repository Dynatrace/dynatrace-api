# http client options
TOO_MANY_REQUESTS_WAIT = "wait"
