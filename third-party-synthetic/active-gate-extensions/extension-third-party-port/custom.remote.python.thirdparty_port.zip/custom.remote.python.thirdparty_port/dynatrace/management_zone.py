class ManagementZone:
    def __init__(self):
        pass
