"""
.. codeauthor:: Tsuyoshi Hombashi <tsuyoshi.hombashi@gmail.com>
"""


class TypeConversionError(TypeError):
    """
    Exception raised when failed to convert data.
    """
