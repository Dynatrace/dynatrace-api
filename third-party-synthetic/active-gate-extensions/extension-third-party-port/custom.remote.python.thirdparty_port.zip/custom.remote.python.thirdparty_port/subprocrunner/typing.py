from typing import Sequence, Union


Command = Union[str, Sequence[str]]
